
package aiprojectphase.pkg2final;


import java.util.Random;
import java.util.Scanner;
import java.util.Arrays;
import java.util.Stack;

public class AIprojectPhase2Final {

    public static Activity[] activityList = new Activity[36]; // array of object
    public static int Budget = 0 ;
    public static  char ActivityType ;
    public static int totalActivity = 0  ;
    public static int [][] population; 
    public static double fitnessArr[] ;
    
    
  
        
    // create population -----------------------------------------------------------------------------------------------------
    
       public static int[][] Initial_Population(int populationCount /*100*/ , int cromosomeLenght /*total activity*/ ) {
          
          population = new int [populationCount][cromosomeLenght]; //array of generation 
          
          Random randomgeneration = new Random();
        for (int i = 0; i < populationCount; i++) { //هنا نمشي على الاراي الكبيرة 
            for (int j = 0; j < cromosomeLenght; j++) { // هنا نمشي على الاراي الصغيرة
                int random = randomgeneration.nextInt(36);
                population[i][j] = random;
            }
        }
        return population;
    }
     // done ----------------------------------------------------------------------------------------------------
   
          public static int removeduplicates(int cromo[], int length)
    {
        if (length == 0 || length == 1) {
            return length;
        }
 
        // creating another array for only storing
        // the unique elements
        int[] temp = new int[length];
        int newLength = 0;
 
        for (int i = 0; i < length - 1; i++) {
            if (cromo[i] != cromo[i + 1]) {
                temp[newLength++] = cromo[i];
            }
        }
 
        temp[newLength++] = cromo[length - 1];
 
        // Changing the original array
        for (int i = 0; i < newLength; i++) {
            cromo[i] = temp[i];
        }
 
        return newLength; }
       
       public static double[] Fitness(int[][] popultion ){
        final double budgetWeight = 0.25;
        final double ActivityNumWeight = 0.25;
        final double TypeWeight = 0.5;
        double fitnessAr[] = new double[popultion.length];
          
        for(int i=0; i<popultion.length; i++) {
              double totalCost = 0 ;
              double countType = 0;
        int newCromLen = removeduplicates(popultion[i] ,popultion[i].length ) ; // remove dublicated activate 
         int actNum = 0 ;    // index  of activite (gene)
        for(int j=0; j<newCromLen; j++) {
            String Strtype ; 
           actNum = popultion[i][j]; // index gene 1
           // type
            Strtype =activityList[actNum].getType() ;// type index
             char type = Strtype.charAt(0);  
             if (type == ActivityType ) 
              countType++ ;
             //cost
           int cost =activityList[actNum].getCost() ;
            totalCost += cost ; 
        } 
        double  budFit = 0 ;
        double  typeFit = TypeWeight * countType/newCromLen  ;
        if (totalCost <= Budget )
          budFit = 0.25 ;
        
         double  actFit = ActivityNumWeight * (newCromLen/totalActivity)  ;
        
         double fittness = budFit + typeFit + actFit ;
        fitnessAr[i] = fittness ;  
         
        }

        return fitnessAr;
    }
       
    //phase 2 ------ Select --------------------------------------------------------------------------------
      
           
        public static int MaxFitness(){ //the index of the biggest fitness
        int maxIndex = 0;
        double max = 0;
        for(int i=0; i<population.length; i++){
            //double fitness[] = Fitness(population);
            if(fitnessArr[i] > max){  //bigest fitness 
                maxIndex = i;
                max = fitnessArr[i];
            }
        }
        return maxIndex;
    }
           
       //Select 
public static int RouletteSelection(double sumFitness[]){
    
         double sumAllFitness = 0 ;
         for(int i=0; i<sumFitness.length; i++){ 
         sumAllFitness+= sumFitness[i] ; }
    
        double rand = Math.random() * sumAllFitness; //معيار //0-1 
        double sum = 0;
        
        for(int i=0; i<sumFitness.length; i++){
            sum += sumFitness[i];
            if(sum >= rand) 
                return i; //choosing parent
        }
        return 0;//impossiple
    }
       
    public static double GenericAlgorithm(double sumFitness[]){
        
        // calculate all fitness values
         double sumAllFitness = 0 ;
         for(int i=0; i<sumFitness.length; i++)
         sumAllFitness+= sumFitness[i] ;
         
        int [][] newGeneration = new int [population.length][36]; //array for new children
        
        for(int index=0; index<(population.length/2); index++){ // half of population
            
            //int [] parentOne = population[RouletteSelection(sumFitness)];
            //int [] parentTwo = population[RouletteSelection(sumFitness)];
            int [] tmp = population[RouletteSelection(sumFitness)];
            int [] parentOne = Arrays.copyOf(tmp, tmp.length);
            
            tmp = population[RouletteSelection(sumFitness)];
            int [] parentTwo = Arrays.copyOf(tmp, tmp.length); 

            int n = parentOne.length;
            
            double CROSS = 0.6 ;// the probability of crossover 
            if(Math.random() < CROSS){ // if less do crossover
                int pos = new Random().nextInt(n);//choose random point
                for(int i=pos; i<n; i++){
                    int t = parentOne[i]; //نفس الداتا ستركتشر 
                    parentOne[i] = parentTwo[i];
                    parentTwo[i] = t;
                }
            } 
            
            double MUTATE = 0.06; //probabilty of mutaion
            if(Math.random() < MUTATE){
                int i = new Random().nextInt(n); //possition random
                if(Math.random() > 0.5){ //probabilty of the change is 50%
            
                Random randomgeneration = new Random(); 
                int random1 = randomgeneration.nextInt(36);
                    parentOne[i] = random1 ; //flip
                }else{
                    Random randomgeneration = new Random();
                    int random2 = randomgeneration.nextInt(36);
                    parentTwo[i] = random2; //flip
                }
            } //end if 
            // for each round will generate 2 children 
            // 0 1
            // 2 3 etc.. 
            newGeneration[2*index] = parentOne; //even 
            newGeneration[2*index+1] = parentTwo; ///odd
        }//loop 
        
        population = newGeneration; // change the population to the new generation
        
        return sumAllFitness/100; // avrg fitness for the new generation 
    }
    
    public static void main(String[] args) {
        
        
        // declare object in the array 
          activityList[0] = new Activity("Boulevard City", "Exciting", 450) ;
          activityList[1] = new Activity("Boulevard World","Exciting", 550) ;
          activityList[2] = new Activity("Winter Wonder land" ,"Exciting", 300) ;
          activityList[3] = new Activity("Middle Beast" ,"Exciting" ,350) ;
          activityList[4] = new Activity("Riyadh Front", "Shopping & Resturants", 500) ;
          activityList[5] = new Activity("U Walk", "Shopping & Resturants" , 400) ;
          activityList[6] = new Activity( "The Zone" , "Shopping & Resturants" , 350) ;
          activityList[7] = new Activity( "The Park Avenue " , "Shopping & Resturants" , 600) ;
          activityList[8] = new Activity( "Albujairi" , "Shopping & Resturants" , 700) ;
          activityList[9] = new Activity( "River Walk" , "Shopping & Resturants" , 400) ;
          activityList[10] = new Activity("Granada Mall", "Shopping & Resturants" , 350);
          activityList[11] = new Activity("Centria Mall", "Shopping & Resturants" , 900);
          activityList[12] = new Activity("Al Maigliah", "Shopping & Resturants" , 200);
          activityList[13] = new Activity("Riyadh Park", "Shopping & Resturants" , 550);
          activityList[14] = new Activity("Al Nakheel Mall", "Shopping & Resturants", 450) ;
          activityList[15] = new Activity("The Kingdom mall", "Shopping & Resturants", 500) ;
          activityList[16] = new Activity("Sky Bridge", "Exciting", 70) ;
          activityList[17] = new Activity("Rawdat Tinhat", "Nature", 50) ;
          activityList[18] = new Activity("Camp Daliah", "Nature", 750) ;
          activityList[19] = new Activity("Horseback Safari", "Nature", 200) ;
          activityList[20] = new Activity("Hiking", "Nature",300) ;
          activityList[21] = new Activity("Red Sands Trip" ,"Nature" , 200) ;
          activityList[22] = new Activity("King Khaled Royal Reserve", "Nature", 350) ;
          activityList[23] = new Activity("Edge of the World", "Nature", 300) ;
          activityList[24] = new Activity("Nofa Wild Life Park", "Nature", 100) ;
          activityList[25] = new Activity("Al Thumamah", "Nature", 300) ;
          activityList[26] = new Activity("Rawdat Kharaim", "Nature", 400) ;
          activityList[27] = new Activity("Camping", "Nature", 1000) ;
          activityList[28] = new Activity("Resorts", "Nature", 1700) ;
          activityList[29] = new Activity("Perfume Expo", "Exciting", 700) ;
          activityList[30] = new Activity("Theatre Shows", "Exciting", 800) ;
          activityList[31] = new Activity("Swimming with Dolphine", "Exciting", 550) ;
          activityList[32] = new Activity("Concert", "Exciting", 700) ;
          activityList[33] = new Activity("Ramez Experience", "Exciting", 200) ;
          activityList[34] = new Activity("Crystal Maze", "Exciting", 300) ;
          activityList[35] = new Activity("Escape Room", "Exciting", 100) ;

          // read from the user 
          Scanner input = new Scanner(System.in);  
          System.out.println("Please Enter Your Name :");
          String name = input.next();
          System.out.println("HI "  + name + " Please enter your trip duration in days." );

         
          System.out.println("Please enter number of activities you prefer to do in Day1 (1 or 2):" );
          int numOfActivity1 = input.nextInt(); //day1
          
           System.out.println("Please enter number of activities you prefer to do in Day2 (1 or 2):" );
          int numOfActivity2 = input.nextInt();//day2
          
           System.out.println("Please enter number of activities you prefer to do in Day3 (1 or 2):" );
          int numOfActivity3 = input.nextInt();//day3
          
           totalActivity = numOfActivity1 + numOfActivity2 + numOfActivity3; //all days
          
         
         System.out.println("Please enter your activity preference (E for Exciting,\n S for Shopping & \n Restaurants and N for Nature)" );
          ActivityType = input.next().toUpperCase().charAt(0);
          
          System.out.println("Please enter your budget in SAR :" );
           Budget = input.nextInt();
 
           // population
            population = Initial_Population(100, totalActivity); //globel
          
            fitnessArr = Fitness(population ); //bt7sb al fitness lkl al chromes fe al population 
           
           double iavrg = 0 ;
            for(int i=0; i<fitnessArr.length; i++)  
           iavrg += fitnessArr[i] ;
            
            iavrg /= fitnessArr.length ;
           
            Stack <Double> generationAvg = new Stack<>(); // بنعبي الافرج حق النيو جنيريشن و نكبها في الاري
            generationAvg.push(iavrg);
            
            //// Termention when we find the optimal soloutuin =1 :)
          while (true) {   
          generationAvg.push(GenericAlgorithm(fitnessArr)); //n3be al stack
             fitnessArr = Fitness (population); //y7sb alfitness ll new genertion
              if (fitnessArr[MaxFitness()] == 1) //optimal solution w8f
                  break;
          } // 5lss
          
        double newGenerAvg[] = new double [generationAvg.size()] ;
        double generationAvgSum = 0 ;
        for (int i= generationAvg.size()-1 ; i >= 0 ; i-- ) {
            newGenerAvg[i] = generationAvg.pop(); 
            generationAvgSum +=  newGenerAvg[i] ;
            System.out.println("Avrege of Genertion number " + i + " : " + newGenerAvg[i]); //y6b3 alvege km mrh dar 3shan ygeb al optimal sloution
        }
        
        System.out.println("Run Aavrge : "+generationAvgSum /newGenerAvg.length  ); 
           
          /*
           for(int genration=0; genration<=100; genration++){
            double fitnessGeneration = GenericAlgorithm(fitnessArr);
            System.out.println("Generation " + genration + ": " + String.format("%.2f", fitnessGeneration));//grah
        }*/
        
        System.out.println("\n"); 

         

          //print -----------------------------------------------
          
          System.out.println("\t\t Chromosom \t Fittness Score" );
          for(int genration=0; genration<population.length; genration++) {
          System.out.print("Generation " + genration + ":" );//grah
              System.out.print("[" );
              for(int j=0; j<population[genration].length; j++)  
           System.out.print(population[genration][j] + "," );
               System.out.print("]" );
          System.out.println( " :\t " +fitnessArr[genration] ); }
          System.out.println("We are working on preparing your optimal trip. . .\n" + "Your trip plan is ready! Your plan is presented below. ");

          
            int plan[] = new int[totalActivity];
            
            int MaxIndex = MaxFitness(); //the biggest fitness
            for(int i=0 ; i<totalActivity ; i++)
             plan[i] = population[MaxIndex][i];  
            
            /*
            
              if (numOfActivity1 == 2  ){ //day 1
                System.out.println("Day 1:"+ plan[0] + "and " + plan[1] ); 
                
              else if (numOfActivity1 == 1)
                System.out.println("Day 1:"+ plan[0]); 
              
              if (numOfActivity2 == 2 )//day 2
                System.out.println("Day 2:"+ plan[2] + "and " + plan[3] ); 
              else if (numOfActivity2 == 1)
                System.out.println("Day 2:"+ plan[2]);
              
               if (numOfActivity3 == 2 )//day 3
                System.out.println("Day 3:"+ plan[4] + "and " + plan[5] ); 
              else if (numOfActivity3 == 1)
                System.out.println("Day 3:"+ plan[4]); 
              */ // we could not use this code 

                
            
                
        int numOfActs[] = new int [3];
        numOfActs[0] = numOfActivity1 ;
        numOfActs[1] = numOfActivity2;
        numOfActs[2] = numOfActivity3;
        
        Stack <Activity> solution = new Stack<>();
        for(int i=0; i<totalActivity; i++){
            plan[i] = population[MaxIndex][i]; 
                solution.add(activityList[plan[i]]);}
        
        for(int day=1; day<=3; day++){
            if(numOfActs[day-1] == 2 && solution.size() > 1)
                System.out.println("Day "+ day +": "+solution.pop().name+" And "+solution.pop().name);
            else if(solution.size() > 0)
                System.out.println("Day "+ day +": "+solution.pop().name);
            
        } 
        System.out.println("Hope you enjoy it! ");

          
          /*
          System.out.println(parentIndex1);
          
          
          for(int i=0; i<totalActivity; i++) 
           System.out.println(population[parentIndex1][i] );
          
            //p2
            
              System.out.println(parentIndex2   );
          
          
          for(int i=0; i<totalActivity; i++) 
           System.out.println(population[parentIndex2][i] );
*/
          
    }
    
}
