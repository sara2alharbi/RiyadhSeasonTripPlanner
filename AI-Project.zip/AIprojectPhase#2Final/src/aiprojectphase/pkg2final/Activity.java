/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aiprojectphase.pkg2final;

/**
 *
 * @author saram
 */
public class Activity {
      String name;

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public int getCost() {
        return cost;
    }
    String type;
    int cost;

    public Activity(String name, String type, int cost) {
        this.name = name;
        this.type = type;
        this.cost = cost;
    }
    
}